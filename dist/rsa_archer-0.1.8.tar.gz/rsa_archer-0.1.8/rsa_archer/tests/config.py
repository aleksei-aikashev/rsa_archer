USERNAME = 'api'
PASSWORD = '....'
ARCHER_DOMAIN = '....'
INSTANCE_NAME = 's_risk_assessment'
APPLICATION = "Incidents"